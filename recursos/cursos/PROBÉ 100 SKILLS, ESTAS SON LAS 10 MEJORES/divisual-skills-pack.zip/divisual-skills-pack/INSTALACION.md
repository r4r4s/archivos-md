# Instalación paso a paso

Si nunca has tocado Claude Code, sigue estos pasos en orden. Tardas 5 minutos.

## Paso 1 — Instala Claude Code

Si todavía no lo tienes en tu ordenador, abre la **Terminal** (en Mac: `Cmd + Espacio`, escribes "Terminal", enter) y pega:

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Cuando termine, escribe `claude` y pulsa enter. Te pedirá iniciar sesión la primera vez.

> ¿En Windows? Instálate primero **WSL** (Ubuntu) y luego pega el mismo comando dentro de Ubuntu.

## Paso 2 — Descomprime el pack

1. Descomprime el archivo `divisual-skills-pack.zip` que has descargado.
2. Mueve la carpeta `divisual-skills-pack/` a donde quieras (por ejemplo, al Escritorio o a `~/Documents/`).

## Paso 3 — Abre la skill que quieras usar

Cada skill se usa de forma **aislada**. Esto significa: te metes dentro de SU carpeta y lanzas Claude Code desde ahí.

Ejemplo — quiero auditar una web con SEO:

```bash
# En la terminal:
cd ~/Desktop/divisual-skills-pack/skills/02-seo-optimizer
claude
```

Cuando Claude Code esté abierto, simplemente escribe lo que quieres en español. Por ejemplo:

> Audita esta web: https://miclienteejemplo.com

La skill se activa sola, hace su trabajo, y te deja los resultados dentro de `workspace/`.

## Cuál usar primero según tu objetivo

| Si quieres… | Empieza por |
|---|---|
| Crear tu primera skill custom | `01-crear-skill` |
| Conseguir clientes para tu agencia | `03-prospeccion` |
| Vender SEO a clientes | `02-seo-optimizer` |
| Vender automatizaciones | `04-n8n-workflow-patterns` |
| Ofrecer consultoría con IA | `05-auditoria-negocio` |
| Mejorar tu canal de YouTube | `08-claude-youtube` |
| Crear una landing desde Instagram | `09-instagram-a-web` |
| Editar tus propios vídeos | `10-video-use` |

## Skill 10 — `video-use` requiere instalación extra

Esta es la única que no funciona "abriendo y ya". Necesita Python, ffmpeg y una API key de ElevenLabs (transcripción).

Si no la vas a usar todavía, **sáltatela**. Cuando la quieras usar, sigue las instrucciones de [`skills/10-video-use/README.md`](skills/10-video-use/README.md).

## Algo no funciona

1. ¿Tienes Claude Code instalado y funcionando? Prueba `claude --version` en la terminal.
2. ¿Estás dentro de la carpeta de la skill correcta? Comprueba con `pwd`.
3. ¿Has leído el `CLAUDE.md` de esa skill concreta? Algunas piden datos antes de empezar.

Si sigues sin avanzar, ven a la sesión gratuita del domingo y lo vemos en directo — link en la descripción del vídeo.

---

Kit empaquetado por **Divisual Project**.
