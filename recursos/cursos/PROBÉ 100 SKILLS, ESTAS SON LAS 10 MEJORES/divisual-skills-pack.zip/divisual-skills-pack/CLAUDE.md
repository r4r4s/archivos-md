# Divisual Skills Pack — Claude Code aplicado a Negocio y Contenido

Bienvenido. Este kit incluye **10 skills curadas** para Claude Code, organizadas en carpetas separadas. Cada una funciona aislada del resto: abres la carpeta de la skill que quieres usar, lanzas Claude Code ahí, y empiezas.

No tienes que aprenderte comandos. Cada skill se activa sola cuando le pides a Claude algo que entra dentro de su ámbito.

¿Primera vez? Léete antes [`INSTALACION.md`](INSTALACION.md).

## Cómo se usa este kit

1. Decide qué quieres hacer (auditar SEO, prospectar clientes, crear un workflow de N8N, editar un vídeo, etc.).
2. Abre la carpeta de la skill correspondiente dentro de `skills/`.
3. Lanza Claude Code desde esa carpeta.
4. Lee el `CLAUDE.md` (o `SKILL.md` en el caso de la 10) de esa skill — te explica qué hace, cómo pedírsela y qué necesita.
5. Haz tu petición en lenguaje natural.

Las skills 01-09 incluyen su propio `workspace/` donde se guardan los outputs.

## Las 10 skills

### Bloque A — Negocio

| Carpeta | Para qué la usas |
|---|---|
| [`skills/01-crear-skill/`](skills/01-crear-skill/) | La meta-skill: crea tus propias skills custom desde cero. |
| [`skills/02-seo-optimizer/`](skills/02-seo-optimizer/) | Audita una web estática y aplica los cambios SEO directamente al código. |
| [`skills/03-prospeccion/`](skills/03-prospeccion/) | Busca leads reales de un nicho y devuelve un dashboard con sus datos. |
| [`skills/04-n8n-workflow-patterns/`](skills/04-n8n-workflow-patterns/) | Genera workflows de N8N desde lenguaje natural. |
| [`skills/05-auditoria-negocio/`](skills/05-auditoria-negocio/) | Diagnóstico completo de un negocio digital con plan de acción. |

### Bloque B — Contenido

| Carpeta | Para qué la usas |
|---|---|
| [`skills/06-create-briefing/`](skills/06-create-briefing/) | Genera el briefing completo de un vídeo de YouTube desde una URL de referencia. |
| [`skills/07-analyze-video/`](skills/07-analyze-video/) | Análisis estructural profundo de un vídeo viral. |
| [`skills/08-claude-youtube/`](skills/08-claude-youtube/) | Orquestador completo para canal de YouTube (14 sub-skills en una). |
| [`skills/09-instagram-a-web/`](skills/09-instagram-a-web/) | Convierte tu perfil de Instagram en una landing profesional. |
| [`skills/10-video-use/`](skills/10-video-use/) | Edita vídeos enteros desde lenguaje natural (transcribe, corta silencios, subtítulos, color, animaciones). |

## Cómo abrir una skill

Por terminal:

```bash
cd skills/02-seo-optimizer
# Aquí lanzas tu editor / Claude Code
```

Cuando estás en esa carpeta, Claude Code solo ve esa skill. No hay contaminación entre skills.

## Reglas que todas las skills respetan

- **Nada inventado.** Si una skill necesita datos del usuario (precios, servicios, contacto, testimonios), los pregunta. Nunca se los inventa.
- **Datos reales primero, preguntas después.** Si puede obtener algo automáticamente (scraping, web search), lo intenta primero.
- **Auto-instalación de dependencias.** Si una skill necesita Playwright, npm packages, etc., los instala automáticamente avisando antes.
- **Sin tarifas inventadas.** El kit no sugiere precios concretos para vender los servicios — eso lo decides tú con tu mercado y experiencia.

## APIs externas con coste

Las skills son gratis. Algunas APIs subyacentes pueden tener coste según el uso:

- **Firecrawl** (skills 03 y 09) — tier gratuito limitado; volumen serio tiene coste.
- **ElevenLabs Scribe** (skill 10) — tier gratuito limitado; volumen serio tiene coste.
- **Anthropic Pro** — recomendado para skills intensivas.

## Requisitos extra de la skill 10 (`video-use`)

A diferencia de las otras 9, `video-use` es un proyecto Python que requiere instalación previa:

```bash
cd skills/10-video-use
pip install -e .
brew install ffmpeg           # macOS
cp .env.example .env
# añadir ELEVENLABS_API_KEY al .env
```

Detalle completo en su [`README.md`](skills/10-video-use/README.md) y [`SKILL.md`](skills/10-video-use/SKILL.md).

## Estructura del kit

```
divisual-skills-pack/
├── README.md       ← versión corta
├── CLAUDE.md       ← este archivo
├── INSTALACION.md  ← guía paso a paso para no-técnicos
└── skills/
    ├── 01-crear-skill/
    │   ├── CLAUDE.md
    │   ├── .claude/skills/crear-skill/
    │   └── workspace/
    ├── 02-seo-optimizer/
    │   └── ...
    └── 10-video-use/
        ├── SKILL.md
        ├── README.md
        ├── helpers/
        └── pyproject.toml
```

---

Kit empaquetado por **Divisual Project**.
