# Divisual Skills Pack para Claude Code

**10 skills** que automatizan trabajo real de negocio digital y de contenido. Cada una en su propia carpeta — abres la que quieras usar y empiezas.

¿Primera vez con Claude Code? Léete antes [`INSTALACION.md`](INSTALACION.md) — son 3 pasos.

## Las 10 skills

### Bloque A — Negocio

| Carpeta | Para qué la usas |
|---|---|
| [`skills/01-crear-skill/`](skills/01-crear-skill/) | La meta-skill: crea tus propias skills custom desde cero. |
| [`skills/02-seo-optimizer/`](skills/02-seo-optimizer/) | Audita una web estática y aplica los cambios SEO directamente al código. |
| [`skills/03-prospeccion/`](skills/03-prospeccion/) | Busca leads reales de un nicho y devuelve un dashboard con sus datos. |
| [`skills/04-n8n-workflow-patterns/`](skills/04-n8n-workflow-patterns/) | Genera workflows de N8N desde lenguaje natural. |
| [`skills/05-auditoria-negocio/`](skills/05-auditoria-negocio/) | Diagnóstico completo de un negocio digital con plan de acción. |

### Bloque B — Contenido

| Carpeta | Para qué la usas |
|---|---|
| [`skills/06-create-briefing/`](skills/06-create-briefing/) | Genera el briefing completo de un vídeo de YouTube desde una URL de referencia. |
| [`skills/07-analyze-video/`](skills/07-analyze-video/) | Análisis estructural profundo de un vídeo viral. |
| [`skills/08-claude-youtube/`](skills/08-claude-youtube/) | Orquestador completo para canal de YouTube (14 sub-skills en una). |
| [`skills/09-instagram-a-web/`](skills/09-instagram-a-web/) | Convierte tu perfil de Instagram en una landing profesional. |
| [`skills/10-video-use/`](skills/10-video-use/) | Edita vídeos enteros desde lenguaje natural (transcribe, corta silencios, subtítulos, color, animaciones). |

## Cómo usar

1. Decide qué quieres hacer (auditar SEO, prospectar clientes, crear un workflow de N8N, etc.).
2. Entra en la carpeta de la skill (`cd skills/02-seo-optimizer`).
3. Lanza Claude Code desde ahí.
4. Lee el `CLAUDE.md` (o `SKILL.md` en el caso de la 10) de esa skill — te dice qué pedirle y qué necesita.
5. Habla con Claude en lenguaje natural. La skill se activa sola.

Cada carpeta de las skills 01-09 incluye un `workspace/` donde se guardan los outputs.

## Detalle completo

Léete `CLAUDE.md` (en esta misma raíz) para ver el índice y las reglas comunes.

---

Kit empaquetado por **Divisual Project**.
