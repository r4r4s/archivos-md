# analyze-video

Análisis estructural profundo de un vídeo viral. Hook segundo a segundo, ganchos de retención, patrones de CTA, estructura narrativa. Te dice qué copiar, qué adaptar y qué evitar.

## Qué hace

Sobre una URL o transcripción, devuelve:

- **Hook** — primeras frases exactas + técnica usada (pregunta, dato impactante, historia, promesa, controversia) + evaluación de si funcionaría en tu canal
- **Estructura narrativa** — bloques con timestamps, arco (problema → desarrollo → solución → CTA), transiciones
- **Bullet points clave** — los 5-10 puntos principales condensados y accionables
- **Patrones de engagement** — preguntas retóricas, storytelling, prueba social, urgencia, CTAs
- **Análisis estratégico** — qué copiar tal cual, qué adaptar, qué evitar
- **Ángulo reutilizable** — propuesta concreta de cómo hacer tu propia versión, con qué pilar de contenido alinea, qué título usar
- **Puntuación** — relevancia para tu audiencia, calidad de estructura, potencial de adaptación

## Cómo activarla

- "Analiza este vídeo y dime qué puedo aprender: [url]"
- "Estudia este vídeo de la competencia: [url]"
- "Extrae aprendizajes de este vídeo viral"
- "Qué hace bien este canal en este vídeo concreto"

## Qué necesita

- **URL del vídeo** (o transcripción pegada).
- Si la skill no conoce tu audiencia ni tus pilares de contenido, te pregunta lo mínimo.

## Lo que hace bien — y lo que no

- **Bien**: análisis directo y práctico, sin relleno. Si un vídeo es mediocre, lo dice sin rodeos.
- **No garantiza éxito**: identifica patrones. Buena estructura con mal tema sigue siendo mal vídeo. Esto solo te da criterio.

## Outputs

`analisis-[canal]-[titulo-corto].md` en `workspace/`. Listo para guardar en tu archivo de referencias o convertir en briefing con la skill 06.
