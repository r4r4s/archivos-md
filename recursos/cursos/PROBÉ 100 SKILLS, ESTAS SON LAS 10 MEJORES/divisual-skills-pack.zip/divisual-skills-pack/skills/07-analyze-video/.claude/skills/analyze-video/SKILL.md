---
name: analyze-video
description: "Analiza transcripciones de vídeos de YouTube de referencia para extraer patrones, estructura, hooks y puntos clave. Usa este skill siempre que el usuario pegue una transcripción de vídeo, mencione analizar un vídeo, quiera extraer bullet points de un vídeo de referencia, o diga 'analiza este vídeo'. También se activa si el usuario menciona estudiar la competencia, ver qué hace otro canal, o extraer aprendizajes de un vídeo ajeno."
---

# Analizar Vídeo de Referencia

Cuando el usuario te pase una transcripción de un vídeo de YouTube, tu trabajo es extraer todo el valor posible para que Juanpe pueda crear mejor contenido.

## Proceso paso a paso

### 1. Carga el contexto
Antes de analizar, lee estos archivos para tener el contexto completo:
- `buyer-persona/persona-principal.md` — para saber qué le importa a la audiencia de Juanpe
- `buyer-persona/pain-points.md` — para identificar qué dolores toca el vídeo
- `buyer-persona/language-patterns.md` — para detectar si el vídeo usa lenguaje que resuena
- `references/channels.md` — para contexto sobre el canal del vídeo
- `knowledge/content-pillars.md` — para evaluar relevancia estratégica

### 2. Pide la metadata
Si el usuario no la proporcionó, pregunta:
- ¿De qué canal es el vídeo?
- ¿Tienes la URL?
- ¿Duración aproximada?

### 3. Analiza la transcripción
Lee la transcripción completa y extrae:

**Hook (primeros 30 segundos)**
- Transcribe las primeras frases exactas
- Identifica la técnica: pregunta, dato impactante, historia, promesa, controversia
- Evalúa si enganchería a la audiencia de Juanpe

**Estructura narrativa**
- Desglosa el vídeo en bloques con timestamps aproximados
- Identifica el arco: problema → desarrollo → solución → CTA
- Nota transiciones y cómo mantiene la atención

**Puntos clave (Bullet Points)**
- Extrae los 5-10 puntos principales, condensados y accionables
- Cada punto debe ser autosuficiente — que se entienda sin ver el vídeo
- Prioriza lo que es útil para la audiencia de Juanpe

**Explicación para Juanpe**
Esta es la sección más importante. No es un resumen — es un análisis estratégico:
- **Qué copiar**: Técnicas o patrones que Juanpe puede usar tal cual
- **Qué adaptar**: Ideas que funcionan pero necesitan ajuste para su audiencia hispanohablante
- **Qué evitar**: Cosas que no encajan con el posicionamiento de Juanpe

**Patrones de engagement**
- Preguntas retóricas que usa
- Storytelling (¿cuenta historias personales? ¿casos de clientes?)
- Prueba social (capturas, testimonios, números)
- Urgencia o escasez
- CTAs (cuántos, dónde, cómo los introduce)

**Conexión con buyer persona**
- ¿Qué dolor específico del buyer persona ataca este vídeo?
- ¿Usa el lenguaje que usa la audiencia de Juanpe?
- ¿Podría este ángulo convertir espectadores en miembros de La Tribu?

**Ángulo reutilizable**
- Propón cómo Juanpe podría hacer su propia versión
- Con qué pilar de contenido se alinea
- Qué título podría usar para su versión

### 4. Puntúa el vídeo
- Relevancia para la audiencia de Juanpe: X/10
- Calidad de estructura: X/10
- Potencial de adaptación: X/10

### 5. Guarda el análisis
Usa la plantilla en `references/videos/TEMPLATE.md` para crear el archivo. Guárdalo en `references/videos/` con el formato:
`references/videos/YYYY-MM-DD-nombre-del-canal-titulo-corto.md`

### 6. Responde al usuario
Después de guardar, muestra al usuario un resumen con:
1. Los bullet points principales (lo que enseña el vídeo)
2. La explicación para Juanpe (qué copiar, adaptar, evitar)
3. El ángulo reutilizable propuesto
4. La puntuación

## Tono del análisis
- Directo y práctico, nada de relleno
- Siempre en español
- Enfocado en lo accionable — no describir por describir
- Si un vídeo es mediocre, decirlo sin rodeos
