# auditoria-negocio

Diagnóstico completo de un negocio digital. Web, redes, ads, copy, customer journey, Google Business, competencia. Salida: informe ejecutivo HTML con plan de acción priorizado.

## Qué hace

Audita 12 dimensiones del negocio:

1. **Web y UX** — primera impresión, propuesta de valor, CTAs, precios visibles, lead capture
2. **SEO básico** — meta tags, headings, contenido
3. **Redes sociales** — bio, link en bio, contenido, frecuencia, coherencia, engagement real
4. **Anuncios (Meta Ads Library)** — qué tiene activo, desde cuándo, copy, coherencia con la web
5. **Copy y comunicación** — ¿habla para el cliente o para sí mismo? ¿CTAs específicos? ¿Tono coherente entre canales?
6. **Oferta y precios** — claridad, coherencia con el posicionamiento
7. **Customer Journey** — completo, incluyendo post-venta (upsell, fidelización, referidos)
8. **Google Business / Maps** — ficha, reseñas, respuestas, coincidencia con la web
9. **Contenido** — blog, frecuencia, calidad
10. **Reputación** — reseñas, social proof, testimonios
11. **Coherencia de marca** — entre canales
12. **Competencia** — si das competidores, comparativa lado a lado

Detecta incoherencias y errores: promesas que no se entregan, precios que no cuadran entre web y redes, mensajes contradictorios, falta de captura de emails, redes abandonadas.

## Cómo activarla

- "Audita este negocio: [url] · servicio que vende: consultoría · objetivo: más leads"
- "Análisis digital completo de mi empresa"
- "Revisa cómo vendo y dime qué estoy haciendo mal"
- "Diagnóstico de mi marca online"

## Qué necesita

**Bloque 1 — lo básico:**
- URL de la web
- Redes sociales (Instagram, TikTok, YouTube, LinkedIn, etc.)
- Qué vende y a qué precio aproximado
- Cliente ideal

**Bloque 2 — contexto estratégico:**
- Objetivo principal ahora (ventas, leads, visibilidad)
- 1-2 competidores directos para comparar
- Canales que usa para vender
- Si tiene una intuición de qué no funciona

Si no quiere dar mucho contexto, trabaja con lo que haya.

## Lo que hace bien

Análisis honesto, no suaviza problemas. El valor de una auditoría está en la verdad.

## Outputs

`auditoria-negocio-[dominio].html` — dashboard ejecutivo con puntuación global, resumen ejecutivo, incoherencias detectadas, mapa del customer journey, análisis de ads, análisis de copy, Google Business, desglose por área, plan de acción priorizado y quick wins de la semana. Todo en `workspace/`.
