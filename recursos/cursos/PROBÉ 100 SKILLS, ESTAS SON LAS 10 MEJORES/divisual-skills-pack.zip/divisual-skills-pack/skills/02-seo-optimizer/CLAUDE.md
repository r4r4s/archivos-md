# seo-optimizer

Audita una web estática y **aplica los cambios SEO directamente en el código**. No te dice qué hacer — lo hace.

## Qué hace

Cubre todas las dimensiones de SEO técnico on-page:

- Meta tags por página (title, description, robots, viewport, charset)
- Open Graph y Twitter Cards para que se vea bien al compartir en redes
- URLs canonical para evitar contenido duplicado
- `lang` correcto y `hreflang` si el sitio es multilingüe
- Jerarquía de headings (un solo H1, orden correcto)
- Imágenes: `alt`, `loading="lazy"`, `width`/`height`
- Anchor text descriptivo en enlaces internos
- Schema.org como JSON-LD (`WebSite`, `Organization`, `Article`, etc.)
- `sitemap.xml` y `robots.txt` creados o verificados
- Hints de performance (preconnect, `font-display: swap`)

Detecta el framework solo (Astro, Next.js, Gatsby, Hugo, Jekyll, Eleventy o HTML plano) y se adapta a la sintaxis de cada uno.

## Cómo activarla

- "Audita el SEO de mi web y aplica los cambios"
- "Quiero subir el ranking en Google de esta landing"
- "Mete schema.org y Open Graph en mi sitio"
- "Optimiza los meta tags de mi web"

## Qué necesita

Apuntar Claude Code a la raíz del proyecto web que quieras auditar. Si tienes una landing estática para probar, mete una copia en `workspace/`.

## Lo que hace bien — y lo que no

- **Bien**: SEO técnico on-page completo aplicado directamente al código.
- **No cubre**: estrategia de contenidos, keyword research profundo, link building. Eso sigue siendo trabajo humano.

## Outputs

Modifica los archivos del proyecto in situ y deja un resumen claro de qué tocó y qué te queda por hacer manualmente (por ejemplo, añadir la imagen OG 1200×630 si no existía).
