---
name: seo-optimizer
description: >
  Comprehensive SEO optimizer for static websites — makes direct code changes to maximize search engine visibility.
  Covers every SEO dimension: meta tags, Open Graph, Twitter Cards, heading hierarchy, sitemap.xml, robots.txt,
  Schema.org structured data (JSON-LD), image optimization (alt text, lazy loading, dimensions), canonical URLs,
  internal linking, language attributes, and performance hints.

  Use this skill whenever the user mentions SEO, Google ranking, meta tags, search visibility, structured data,
  sitemap, robots.txt, or wants their static site to perform better on search engines — even if they don't
  explicitly say "SEO". If the user has a web project and mentions wanting more traffic, better indexing,
  or appearing in search results, this skill applies. Trigger it proactively.
---

# SEO Optimizer for Static Websites

Your job is to **directly apply all SEO improvements** to the project — not just audit and report. Read the files, identify what's missing or wrong, and fix it.

## Phase 1: Discover the Project

Start by understanding the structure before touching anything.

1. Identify the framework by looking for config files: `astro.config.*`, `next.config.*`, `gatsby-config.*`, `hugo.toml`, `_config.yml` (Jekyll), `.eleventy.js`, or plain HTML files.
2. Find where pages live: `src/pages/`, `pages/`, `content/`, `public/`, or `.html` files at the root.
3. Find the main layout/template file — the one that wraps all pages (usually `src/layouts/`, `_layouts/`, `components/Layout.*`, or `src/components/`).
4. Check what already exists: any `sitemap.xml`, `robots.txt`, existing meta tags, or `<head>` structure.
5. Check the `public/` or `static/` or `dist/` folder for assets.

The goal is to understand: **Where is the `<head>` rendered?** That's where most changes happen.

## Phase 2: Apply SEO Improvements

Work systematically through every category below. For each one, read the relevant files first, then make the changes. Don't skip categories — if something doesn't apply (e.g., no images in the project), note it briefly and move on.

---

### 1. Meta Tags (per page)

Every page needs:
```html
<title>Page Title – Site Name</title>
<meta name="description" content="Clear, compelling description under 160 characters.">
<meta name="robots" content="index, follow">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

- If the framework uses a layout template, add dynamic title/description support (e.g., via props, frontmatter, or Astro's `<slot name="head">`).
- If pages already have titles, improve them: they should be unique, under 60 characters, and include the main keyword first.
- Descriptions should be unique per page, conversational, and include a soft call to action.

---

### 2. Open Graph Tags

Add to every page's `<head>`:
```html
<meta property="og:type" content="website">
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Same or similar to meta description">
<meta property="og:url" content="https://yourdomain.com/page-path">
<meta property="og:image" content="https://yourdomain.com/og-image.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:site_name" content="Site Name">
<meta property="og:locale" content="es_ES">  <!-- or en_US, etc. -->
```

If there's no OG image, note it clearly so the user can add one later (size: 1200×630px).

---

### 3. Twitter Cards

```html
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Description">
<meta name="twitter:image" content="https://yourdomain.com/og-image.jpg">
```

---

### 4. Canonical URLs

Every page needs a self-referencing canonical to prevent duplicate content:
```html
<link rel="canonical" href="https://yourdomain.com/current-page-path">
```

In templates, make this dynamic based on the current page URL. If you don't know the domain, use a placeholder `YOUR_DOMAIN` and add a comment for the user to replace it.

---

### 5. Language and Accessibility

- Ensure `<html lang="es">` (or the correct language) is set on every page.
- If the site is multilingual, add `<link rel="alternate" hreflang="...">` tags.

---

### 6. Heading Structure

Read the content of each page and verify:
- Each page has **exactly one `<h1>`** that matches or is close to the page title.
- Headings follow a logical hierarchy: H1 → H2 → H3 (no skipping levels).
- The H1 appears near the top of the content, not buried.

Fix any violations directly in the HTML/template/MDX files.

---

### 7. Images

For every `<img>` tag in the project:
- Add `alt` attribute with a descriptive text (not "image" or empty for non-decorative images; use `alt=""` only for purely decorative images).
- Add `loading="lazy"` to images that are below the fold (all images except the hero/first image).
- Add explicit `width` and `height` attributes to prevent layout shift (CLS).
- If the framework supports it, suggest or apply modern formats (WebP/AVIF) via `<picture>` elements.

---

### 8. Internal Links

- All `<a>` tags should have descriptive anchor text — replace "click here", "read more", "here" with meaningful text like "view our pricing page".
- Check that important pages are linked from the homepage or main navigation.
- No broken links to internal pages (check that linked files/routes exist in the project).

---

### 9. Schema.org Structured Data (JSON-LD)

Add JSON-LD to pages. At minimum, add a `WebSite` schema to the homepage layout:
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "Site Name",
  "url": "https://yourdomain.com",
  "description": "Site description",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://yourdomain.com/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
```

For blog posts or articles, add `Article` or `BlogPosting` schema. For business sites, add `Organization` or `LocalBusiness`. Read `references/schema-templates.md` for ready-to-use templates.

---

### 10. sitemap.xml

Check if a sitemap exists at the root (`public/sitemap.xml`, `static/sitemap.xml`, or generated by the framework).

- **If the framework generates it automatically** (Astro with `@astrojs/sitemap`, Next.js with `next-sitemap`, Gatsby with `gatsby-plugin-sitemap`): verify it's configured and enabled. If not, add the configuration.
- **If there's no sitemap at all**: generate a `sitemap.xml` by listing all HTML pages found in the project. Place it in the `public/` or `static/` folder.

Basic sitemap format:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://yourdomain.com/</loc>
    <lastmod>2024-01-01</lastmod>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```

---

### 11. robots.txt

Check if `robots.txt` exists. If not, create one in the root/public folder:
```
User-agent: *
Allow: /

Sitemap: https://yourdomain.com/sitemap.xml
```

If it exists, verify it's not accidentally blocking important pages (`Disallow: /` is a common mistake).

---

### 12. Performance Hints (Bonus SEO)

In the `<head>`, add preconnect for any third-party domains used (Google Fonts, CDNs, analytics):
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
```

For the main font, use `font-display: swap` in the CSS to avoid invisible text during load.

---

## Phase 3: Final Summary

After making all changes, provide a clear summary:

```
## SEO Optimization Complete

### Changes made:
- [list each file modified and what was changed]

### Files created:
- sitemap.xml — [number] pages indexed
- robots.txt — crawler access configured

### Action required from you:
- Replace YOUR_DOMAIN with your actual domain in [files]
- Add an OG image (1200×630px) at [path] — used for social sharing
- [any other manual steps]

### SEO score estimate: [before] → [after]
```

Be honest about what you couldn't do (e.g., if the domain isn't known, or images aren't available).

---

## Important Notes

- **Always read a file before editing it.** Never guess the structure.
- **Make changes incrementally** — one file at a time, not a big rewrite.
- **Don't break functionality** — if you're unsure about a framework-specific syntax, add a comment instead of guessing.
- **Framework-aware**: In React/Next.js use `<Head>` from `next/head` or metadata exports. In Astro use frontmatter and `<slot>`. In plain HTML edit `<head>` directly.
- If you find SEO elements that are already good, leave them alone and note them as "already optimized".
