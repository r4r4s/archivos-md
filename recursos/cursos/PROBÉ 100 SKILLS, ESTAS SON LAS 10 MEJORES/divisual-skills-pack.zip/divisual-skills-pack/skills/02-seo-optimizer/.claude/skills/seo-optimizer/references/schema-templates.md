# Schema.org JSON-LD Templates

Ready-to-use structured data templates. Replace placeholders with real values.

---

## WebSite (homepage)

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "SITE_NAME",
  "url": "https://YOUR_DOMAIN",
  "description": "SITE_DESCRIPTION",
  "inLanguage": "es",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://YOUR_DOMAIN/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
```

---

## WebPage (generic page)

```json
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "PAGE_TITLE",
  "description": "PAGE_DESCRIPTION",
  "url": "https://YOUR_DOMAIN/page-path",
  "inLanguage": "es",
  "isPartOf": {
    "@type": "WebSite",
    "name": "SITE_NAME",
    "url": "https://YOUR_DOMAIN"
  }
}
```

---

## Article / BlogPosting

```json
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "ARTICLE_TITLE",
  "description": "ARTICLE_DESCRIPTION",
  "url": "https://YOUR_DOMAIN/blog/article-slug",
  "datePublished": "2024-01-01",
  "dateModified": "2024-01-01",
  "inLanguage": "es",
  "author": {
    "@type": "Person",
    "name": "AUTHOR_NAME",
    "url": "https://YOUR_DOMAIN/about"
  },
  "publisher": {
    "@type": "Organization",
    "name": "SITE_NAME",
    "url": "https://YOUR_DOMAIN",
    "logo": {
      "@type": "ImageObject",
      "url": "https://YOUR_DOMAIN/logo.png"
    }
  },
  "image": {
    "@type": "ImageObject",
    "url": "https://YOUR_DOMAIN/blog/article-image.jpg",
    "width": 1200,
    "height": 630
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://YOUR_DOMAIN/blog/article-slug"
  }
}
```

---

## Organization

```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "COMPANY_NAME",
  "url": "https://YOUR_DOMAIN",
  "logo": "https://YOUR_DOMAIN/logo.png",
  "description": "COMPANY_DESCRIPTION",
  "contactPoint": {
    "@type": "ContactPoint",
    "email": "contact@YOUR_DOMAIN",
    "contactType": "customer support"
  },
  "sameAs": [
    "https://twitter.com/HANDLE",
    "https://linkedin.com/company/COMPANY",
    "https://instagram.com/HANDLE"
  ]
}
```

---

## LocalBusiness

```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "BUSINESS_NAME",
  "description": "BUSINESS_DESCRIPTION",
  "url": "https://YOUR_DOMAIN",
  "telephone": "+34-XXX-XXX-XXX",
  "email": "info@YOUR_DOMAIN",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Calle Ejemplo 123",
    "addressLocality": "Madrid",
    "addressRegion": "Madrid",
    "postalCode": "28001",
    "addressCountry": "ES"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 40.4168,
    "longitude": -3.7038
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "18:00"
    }
  ],
  "image": "https://YOUR_DOMAIN/business-photo.jpg",
  "priceRange": "€€"
}
```

---

## BreadcrumbList

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://YOUR_DOMAIN"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Blog",
      "item": "https://YOUR_DOMAIN/blog"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Article Title",
      "item": "https://YOUR_DOMAIN/blog/article-slug"
    }
  ]
}
```

---

## FAQPage

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "¿Cuál es la pregunta?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Esta es la respuesta detallada a la pregunta."
      }
    },
    {
      "@type": "Question",
      "name": "¿Otra pregunta?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Respuesta a la segunda pregunta."
      }
    }
  ]
}
```
