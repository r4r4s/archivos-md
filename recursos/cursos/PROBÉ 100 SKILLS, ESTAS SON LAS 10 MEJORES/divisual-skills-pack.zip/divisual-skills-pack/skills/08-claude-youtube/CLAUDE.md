# youtube

Orquestador completo para canal de YouTube. Auditoría, SEO, scripts, hooks, thumbnails, estrategia, calendario, shorts, analytics, repurposing, monetización, competencia, metadata, ideas. 14 sub-skills en una.

## Qué hace

Tienes un comando por área. La skill identifica cuál necesitas y aplica el playbook correspondiente:

| Comando | Para qué |
|---|---|
| `/youtube audit` | Auditoría completa del canal (4 agentes en paralelo: técnico SEO, performance, estrategia, monetización) |
| `/youtube seo` | Keyword research + optimización de títulos, descripciones, tags, capítulos |
| `/youtube script` | Script completo con retención engineered |
| `/youtube hook` | Mejora del primer 30 segundos |
| `/youtube thumbnail` | Brief de miniatura (o generación con NanoBanana si está configurado) |
| `/youtube strategy` | Posicionamiento, nicho, plan de contenido |
| `/youtube calendar` | Calendario de contenido estacional |
| `/youtube shorts` | Estrategia de Shorts |
| `/youtube analyze` | Interpretación de analytics (por qué bajan las views, qué métrica vigilar) |
| `/youtube repurpose` | Convertir un vídeo en clips, posts, hilos |
| `/youtube monetize` | YPP, brand deals, memberships, otras vías |
| `/youtube competitor` | Análisis profundo de un competidor |
| `/youtube metadata` | Paquete de metadata copy-paste para subir el vídeo |
| `/youtube ideate` | Ideas de vídeo basadas en gaps de contenido + trends |

## Cómo activarla

- `/youtube audit` o "audita mi canal: [url]"
- "Mejora el SEO de este vídeo"
- "Dame ideas de vídeo para mi canal de [tema]"
- "Cómo monetizo mi canal de 5K subs"
- "Analiza la estrategia de [canal competidor]"

## Qué necesita

Antes de empezar cualquier sub-skill, te pide tres cosas:

1. **Nicho/topic** específico (no "tech" — "reviews de móviles Android baratos")
2. **Tier de tamaño** (< 1K / 1K-10K / 10K-100K / 100K+)
3. **Objetivo principal** (crecimiento / monetización / autoridad / engagement)

Para `audit`, `analyze` y `competitor` también pide la URL del canal.

## Lo que hace bien

- Cargado con playbooks reales: algoritmo, SEO, retention, thumbnails, monetización, analytics, repurposing.
- Detecta el tipo de canal (educación, entretenimiento, tutorial, vlog, review, commentary, autoridad nicho, marca personal, shorts-first) y aplica el template correcto.
- Para auditorías y análisis de competencia, lanza 4 agentes en paralelo para acelerar.

## Integraciones opcionales

- **DataForSEO MCP** — si está configurado, usa datos reales de YouTube SERP, volumen de keywords, trends. Si no, hace fallback a WebSearch.
- **NanoBanana MCP** — para generar miniaturas reales en vez de solo briefs.

## Outputs

Por defecto markdown. Para `metadata` produce bloques copy-paste listos. Para `calendar` produce tabla. Para `audit` produce informe estructurado con puntuación. Todo en `workspace/`.
