# prospeccion

Buscas negocios reales de un nicho, analizas su presencia digital, los puntúas según el servicio que ofreces y obtienes un dashboard con los mejores prospectos y sus datos de contacto.

## Qué hace

1. Te pregunta nicho + ubicación + servicio que ofreces + cuántos prospectos quieres.
2. Busca negocios reales (WebSearch, Firecrawl si está disponible, Playwright como fallback).
3. Analiza la web de cada uno: si tiene web, HTTPS, responsive, SEO básico, redes sociales, Google Business, diseño moderno o no.
4. Puntúa cada negocio de 0-100 según el servicio que vendes (sin web = 100 si vendes webs; sin meta tags = 100 si vendes SEO; etc.).
5. Genera dashboard HTML con tabla de prospectos, fichas detalladas de los top 5-10, mensajes de contacto personalizados y estadísticas del nicho.
6. Exporta también un JSON crudo para CRM o Sheets.

## Cómo activarla

- "Busca 50 agencias de marketing pequeñas en Valencia con sus contactos públicos"
- "Quiero hacer prospección de clínicas dentales en Madrid"
- "Encuentra leads de gimnasios sin web en Barcelona"
- "Lista de restaurantes en Sevilla para venderles SEO"

## Qué necesita

- **Nicho** específico (no "negocios", sí "clínicas dentales").
- **Ubicación** (ciudad, provincia o zona).
- **Servicio que vendes** (afecta a cómo se puntúa la oportunidad).
- **Volumen** (10, 25, 50...).

## Lo que hace bien — y lo que no

- **Bien**: solo datos reales y verificados. Nunca inventa negocios ni teléfonos.
- **Aviso RGPD obligatorio**: solo contactos públicos profesionales. Si haces cold email, incluye opt-out claro. La skill no te exime de cumplir la ley.
- **Si quieres volumen serio**, Firecrawl deja de ser gratis. Tier free es para arrancar.

## Outputs

- `prospeccion-[nicho]-[ciudad].html` — dashboard visual
- `prospeccion-[nicho]-[ciudad].json` — datos crudos para CRM/Sheets

Ambos en `workspace/`.
