---
name: create-briefing
description: "Crea briefings completos para los próximos vídeos de YouTube de Juanpe — incluye título, hook con guión, estructura, bullet points, CTAs y conexión con el embudo de ventas. Usa este skill cuando el usuario quiera preparar un vídeo, pida un briefing, diga 'hazme el guión de un vídeo', 'prepárame el próximo vídeo', 'quiero hacer un vídeo sobre X', o cualquier variación de planificar contenido para YouTube. También se activa si menciona crear un guión, estructurar un vídeo, o necesitar un outline."
---

# Crear Briefing de Vídeo

Cuando Juanpe quiera preparar un nuevo vídeo, tu trabajo es entregarle un briefing tan completo que solo tenga que sentarse y grabar.

## Proceso paso a paso

### 1. Carga todo el contexto
Lee estos archivos antes de crear el briefing:
- `knowledge/about-me.md` — quién es Juanpe y su ecosistema
- `knowledge/brand-voice.md` — su tono y estilo
- `knowledge/content-pillars.md` — pilares estratégicos
- `knowledge/channel-strategy.md` — objetivos del canal
- `buyer-persona/persona-principal.md` — perfil de la audiencia
- `buyer-persona/pain-points.md` — dolores que atacar
- `buyer-persona/language-patterns.md` — lenguaje que usan

También revisa `references/videos/` para ver si hay análisis de vídeos que puedan inspirar el briefing.

### 2. Entiende el pedido
Si el usuario solo dice un tema general (ej: "quiero hacer un vídeo sobre N8N"), haz preguntas para afinar:
- ¿Qué aspecto específico? (tutorial, caso de uso, comparativa...)
- ¿Nivel de la audiencia? (principiante, intermedio, avanzado)
- ¿Hay algún vídeo de referencia que le inspire?
- ¿Objetivo principal? (atraer nuevos, educar existentes, convertir a La Tribu)

Si el usuario ya dio suficiente contexto, no preguntes — genera directamente.

### 3. Genera el briefing completo

**Título y Thumbnail**
- 3 opciones de título, ordenadas por potencial de click
- Cada título debe: incluir un beneficio claro, generar curiosidad, usar palabras del buyer persona
- Concepto de thumbnail: texto overlay, emoción del rostro, referencia visual

**Hook (primeros 30 segundos)**
- Escribe el guión literal — palabra por palabra lo que Juanpe debería decir
- El hook debe tocar un dolor del buyer persona en las primeras 5 segundos
- Incluye la promesa del vídeo (qué va a aprender el espectador)
- Explica por qué este hook funciona (qué dolor toca, qué curiosidad genera, qué promete)

**Estructura completa**
Divide el vídeo en bloques con tiempos orientativos:
1. **Hook + Contexto** [0:00 - 1:00] — enganchar y contextualizar
2. **Problema** [1:00 - 3:00] — amplificar el dolor, que el espectador se sienta identificado
3. **Desarrollo** [3:00 - X:XX] — el contenido principal, dividido en puntos claros
4. **Resultado / Prueba** [X:XX - X:XX] — mostrar que funciona (demo, caso real, números)
5. **CTA + Cierre** [X:XX - final] — cerrar con acción clara

Para cada bloque, incluye:
- Qué decir (ideas clave, no guión completo excepto el hook)
- Qué mostrar en pantalla
- Transición al siguiente bloque

**Bullet Points clave**
Los 5 puntos que el espectador debe recordar. Estos son los puntos que, si alguien pregunta "¿de qué iba el vídeo?", debería poder responder.

**Notas para Juanpe**
- Lo que debe transmitir (energía, urgencia, cercanía...)
- Lo que debe evitar (ser demasiado técnico, perder el foco...)
- Si aplica integración de sponsor (Hostinger): momento ideal y transición natural

**Conexión con el embudo**
- ¿De dónde llega el espectador? (búsqueda, sugeridos, suscriptores)
- ¿A dónde lo mandamos? (La Tribu, otro vídeo, lead magnet)
- Frase de conversión sugerida (CTA para La Tribu si es relevante)

### 4. Guarda el briefing
Usa la plantilla en `my-videos/briefings/TEMPLATE.md`. Guárdalo con el formato:
`my-videos/briefings/YYYY-MM-DD-titulo-corto.md`

### 5. Responde al usuario
Muestra el briefing completo al usuario. Destaca especialmente:
- El hook (para que lo pueda practicar)
- La estructura (para que sepa el flujo)
- Los bullet points (para que no se le olvide nada)

## Principios del briefing

- **Cada vídeo ataca un dolor específico** — si no hay dolor claro, el vídeo no enganchará
- **El hook es el 80% del éxito** — dedica el mayor esfuerzo aquí
- **Menos es más** — 5 puntos bien explicados > 15 puntos superficiales
- **Siempre conectar con el embudo** — YouTube es el top of funnel de Juanpe, cada vídeo debe tener un camino natural hacia La Tribu
- **Usar el lenguaje del buyer persona** — las palabras exactas que ellos usan, no jerga de marketing
- **Siempre en español**
