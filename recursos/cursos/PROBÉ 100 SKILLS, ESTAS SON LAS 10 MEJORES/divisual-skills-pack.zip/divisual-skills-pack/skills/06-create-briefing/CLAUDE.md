# create-briefing

Genera el briefing completo de un vídeo de YouTube a partir de la URL de un vídeo que ya esté funcionando en tu nicho. Te ahorra horas de preparación y te deja un guion listo para grabar.

## Qué hace

1. Extrae la transcripción del vídeo de referencia.
2. Analiza la estructura: hook, beats, patrón de retención, CTAs.
3. Identifica qué hace bien y qué hace mal.
4. Genera un briefing adaptado a TU canal con:
   - 3 opciones de título
   - Concepto de miniatura
   - Hook literal (palabra por palabra)
   - Estructura del vídeo bloque a bloque con tiempos
   - Bullet points clave (los 5 puntos que la audiencia debe recordar)
   - Notas para grabar (qué transmitir, qué evitar, integración de sponsor si aplica)
   - Conexión con el embudo de ventas

## Cómo activarla

- "Hazme el briefing de un vídeo a partir de esta URL: [url]"
- "Prepárame el próximo vídeo basado en este: [url]"
- "Quiero hacer mi versión de este vídeo: [url]"
- "Estructura un vídeo sobre [tema] usando este como referencia"

## Qué necesita

- **URL del vídeo de referencia** (obligatorio).
- **Tu nicho y posicionamiento** — si la skill no lo tiene cargado de antes, te lo pregunta.
- **Objetivo del vídeo** — atraer nuevos, educar existentes, convertir...

## Lo que hace bien — y lo que no

- **Bien**: estructura entera lista para grabar, hook palabra por palabra, conexión con tu embudo.
- **No es para copiar**: extrae la estructura de lo que funciona y la adapta a tu voz. Si lo lanzas tal cual, parece IA y rompe tu autoridad.

## Outputs

Briefing en HTML guardado en `workspace/` con la fecha y el tema del vídeo. Listo para imprimir o leer en pantalla mientras grabas.
