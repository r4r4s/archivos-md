# n8n-workflow-patterns

Genera workflows de N8N desde lenguaje natural usando los 5 patrones arquitecturales más comunes.

## Qué hace

Conoce los 5 patrones que cubren el 90% de los casos de uso de N8N:

1. **Webhook Processing** — recibe HTTP → procesa → responde (el más común)
2. **HTTP API Integration** — pull de APIs externas → transforma → almacena
3. **Database Operations** — sincroniza, ETL, queries programadas
4. **AI Agent Workflow** — agentes con tools y memory
5. **Scheduled Tasks** — automatizaciones recurrentes (cron)

Describes el workflow que necesitas en lenguaje natural y te genera el JSON listo para importar en N8N. Conoce los gotchas más comunes (estructura `$json.body` en webhooks, autenticación, execution order, expresiones).

## Cómo activarla

- "Necesito un workflow que cada lunes me mande a Drive un Excel con los pedidos de WooCommerce de la semana"
- "Quiero un webhook en N8N que reciba formularios y los mande a Slack"
- "Workflow para sincronizar Postgres con MySQL cada 15 minutos"
- "Agente de IA en N8N que consulte mi base de datos"

## Qué necesita

Una descripción clara de:
- El **trigger** (webhook, schedule, manual, polling)
- La **fuente de datos** (qué API, qué base de datos, etc.)
- La **transformación** (qué tiene que hacer con los datos)
- El **output** (a dónde manda el resultado)

Si no tienes claro alguno, la skill te pregunta.

## Lo que hace bien — y lo que no

- **Bien**: aplica patrones probados, conoce los nodos correctos, evita los gotchas típicos.
- **No es producción al 100%**: el JSON generado es punto de partida. Tienes que conectar credenciales, validar lógica de errores y probar con datos reales antes de activarlo en serio.

## Outputs

El JSON del workflow se guarda en `workspace/`. Lo importas en N8N (`Import from File`) y queda listo para configurar credenciales.
