# instagram-a-web

Convierte un perfil de Instagram en una landing profesional de marca personal. Se adapta al tipo de creador (fotógrafo, coach, influencer, freelancer, nutricionista, artista, etc.).

## Qué hace

1. Le das tu @handle de Instagram.
2. Intenta scrapear el perfil con Firecrawl o Playwright (instala lo que falte). Si Instagram lo bloquea, te pide los datos y fotos manualmente con instrucciones claras.
3. Busca al usuario en otras redes (TikTok, YouTube, LinkedIn, Twitter, Skool, etc.) para sumar comunidad total y encontrar testimonios públicos.
4. Te pregunta lo que falta: bio expandida, servicios reales con precios, email, colores de marca, eslogan.
5. Detecta el tipo de marca personal y adapta el diseño (tono, secciones, CTAs).
6. Genera una landing HTML autocontenida (todo inline, sin dependencias) con animaciones de scroll, hero estilo IG, galería con tus fotos reales, sección de servicios, testimonios reales si los hay, contacto y enlaces a todas tus redes.

## Cómo activarla

- "Convierte mi Instagram @mihandle en una web"
- "Web de marca personal a partir de mi perfil de IG"
- "Landing desde mi @"
- "Quiero una web como mi perfil"

## Qué necesita

- **@handle de Instagram** (obligatorio).
- **Bio y a qué te dedicas** (si no se puede scrapear).
- **Servicios reales con precios** — si no quieres poner precios, se respeta y pone "bajo presupuesto".
- **Email o contacto.**
- **Colores de marca** o referencia (opcional).
- **Testimonios reales** si tienes (Skool, web, etc.) — solo reales, nunca inventados.
- **6-12 fotos** de tus posts si el scraping falla (te crea la carpeta `workspace/assets/instagram/` para que las metas tú).

## Lo que hace bien — y lo que no

- **Bien**: nada inventado nunca. Cada servicio, precio, testimonio y dato sale de ti o del perfil real.
- **Es punto de partida**: la landing generada se debe revisar antes de entregar (copy, imágenes, CTA). Si la sueltas tal cual sale, se nota que es IA y quemas tu autoridad.

## Outputs

- `web-[handle].html` — landing autocontenida lista para deploy
- `workspace/assets/instagram/` — fotos descargadas del perfil

Todo en `workspace/`.
