# crear-skill

La meta-skill: la skill que crea skills. Conviertes cualquier proceso repetitivo de tu día a día en una skill propia que puedes reutilizar y compartir.

## Qué hace

Te guía paso a paso para crear una skill custom:

1. Te pregunta qué proceso quieres automatizar.
2. Diseña el flujo (qué input recibe, qué pasos sigue, qué output devuelve).
3. Genera el archivo `SKILL.md` completo con frontmatter válido y triggers correctos.
4. Lo instala donde le digas (proyecto actual o globalmente).
5. Opcionalmente crea un kit completo para compartir la skill con tus clientes o equipo.

## Cómo activarla

Habla en lenguaje natural. Se activa automáticamente con frases como:

- "Quiero crear una skill para auditar la velocidad de carga de una landing"
- "Convierte esto en una skill: cada vez que reciba un email de un nuevo lead..."
- "Necesito una skill que me genere propuestas comerciales desde un brief"
- "Automatiza este proceso como skill"

## Lo que hace bien

- Te pregunta lo justo, no te interroga.
- Genera triggers múltiples y variados para que la skill se active de muchas formas.
- Aplica buenas prácticas: nada inventado, datos reales primero, auto-instalación de dependencias.
- Te puede crear el kit entero (`CLAUDE.md` + `INSTRUCCIONES.md` + skill) si quieres distribuirla.

## Outputs

Los `SKILL.md` que generes se guardan donde le pidas. Si creas un kit completo, va a `workspace/` por defecto.
